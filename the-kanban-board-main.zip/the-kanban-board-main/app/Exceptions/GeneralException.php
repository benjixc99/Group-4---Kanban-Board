<?php

namespace App\Exceptions;

use Exception;

class GeneralException extends Exception
{
    //
}
